<?php

return [
'App_Name' => 'Chatter'
]

?>
